print('Not showing this text because it is outside the snippet')

## [hello_world]
print('Hello world!')
## [hello_world]
